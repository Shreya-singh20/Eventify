const express = require('express');
const { protect, authorize, optionalAuth } = require('../middleware/auth');
const { upload } = require('../config/cloudinary');
const {
  validateRegister, validateLogin, validateCreateEvent,
  validateFeedback, validateChangePassword, validatePagination,
} = require('../middleware/validate');

// ─── Auth ─────────────────────────────────────────────────────────────────────
const { register, login, getProfile, updateProfile, changePassword, logout } = require('../controllers/authController');
const authRouter = express.Router();
authRouter.post('/register', validateRegister, register);
authRouter.post('/login',    validateLogin,    login);
authRouter.get('/profile',   protect, getProfile);
authRouter.put('/profile',   protect, upload.single('avatar'), updateProfile);
authRouter.put('/change-password', protect, validateChangePassword, changePassword);
authRouter.get('/logout',    protect, logout);

// ─── Events ───────────────────────────────────────────────────────────────────
const { getEvents, getEvent, createEvent, updateEvent, deleteEvent, approveEvent, getMyEvents, getAttendance, markAttendance } = require('../controllers/eventController');
const eventRouter = express.Router();
eventRouter.get('/',           optionalAuth, validatePagination, getEvents);
eventRouter.get('/my-created', protect, authorize('organizer','admin'), getMyEvents);
eventRouter.get('/:id',        optionalAuth, getEvent);
eventRouter.post(
  '/create',
  protect,
  authorize('organizer','admin'),
  upload.single('image'),   // MUST be here
  (req, res, next) => {
    console.log("BODY AFTER UPLOAD:", req.body); // 👈 add this
    next();
  },
  validateCreateEvent,
  createEvent
);
eventRouter.put('/:id',        protect, authorize('organizer','admin'), updateEvent);
eventRouter.delete('/:id',     protect, authorize('organizer','admin'), deleteEvent);
eventRouter.put('/:id/approve',    protect, authorize('admin'), approveEvent);
eventRouter.get('/:id/attendance', protect, authorize('organizer','admin'), getAttendance);
eventRouter.put('/:id/attendance', protect, authorize('organizer','admin'), markAttendance);

// ─── Registration ─────────────────────────────────────────────────────────────
const { registerForEvent, getMyRegisteredEvents, cancelRegistration } = require('../controllers/registrationController');
const registrationRouter = express.Router();
registrationRouter.post('/:eventId',          protect, registerForEvent);
registrationRouter.get('/my-events',          protect, getMyRegisteredEvents);
registrationRouter.delete('/cancel/:eventId', protect, cancelRegistration);

// ─── Certificates ─────────────────────────────────────────────────────────────
const { getMyCertificates, generateCertificate, downloadCertificate, getNotifications, markNotificationsRead, getAdminStats } = require('../controllers/certificateController');
const certRouter = express.Router();
certRouter.get('/',             protect, getMyCertificates);
certRouter.post('/generate',    protect, authorize('organizer','admin'), generateCertificate);
certRouter.get('/:id/download', protect, downloadCertificate);

const notifRouter = express.Router();
notifRouter.get('/',     protect, getNotifications);
notifRouter.put('/read', protect, markNotificationsRead);

// ─── Clubs, Feedback, Admin Users ────────────────────────────────────────────
const { getClubs, getClub, createClub, updateClub, joinClub, leaveClub, submitFeedback, getEventFeedback, getUsers, updateUserRole, toggleUserActive, deleteUser } = require('../controllers/clubController');

const clubRouter = express.Router();
clubRouter.get('/',            getClubs);
clubRouter.get('/:slug',       getClub);
clubRouter.post('/',           protect, authorize('organizer','admin'), createClub);
clubRouter.put('/:id',         protect, authorize('organizer','admin'), updateClub);
clubRouter.post('/:id/join',   protect, joinClub);
clubRouter.delete('/:id/leave',protect, leaveClub);

const feedbackRouter = express.Router();
feedbackRouter.post('/:eventId', protect, validateFeedback, submitFeedback);
feedbackRouter.get('/:eventId',  optionalAuth, getEventFeedback);

const adminRouter = express.Router();
adminRouter.get('/stats',            protect, authorize('admin'), getAdminStats);
adminRouter.get('/users',            protect, authorize('admin'), getUsers);
adminRouter.put('/users/:id/role',   protect, authorize('admin'), updateUserRole);
adminRouter.put('/users/:id/toggle', protect, authorize('admin'), toggleUserActive);
adminRouter.delete('/users/:id',     protect, authorize('admin'), deleteUser);

module.exports = { authRouter, eventRouter, registrationRouter, certRouter, notifRouter, clubRouter, feedbackRouter, adminRouter };
