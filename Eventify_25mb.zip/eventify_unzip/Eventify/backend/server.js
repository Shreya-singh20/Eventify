require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const morgan  = require('morgan');
const rateLimit = require('express-rate-limit');
const connectDB = require('./config/db');
const errorHandler = require('./middleware/error');
const {
  authRouter, eventRouter, registrationRouter,
  certRouter, notifRouter, clubRouter, feedbackRouter, adminRouter,
} = require('./routes/index');

connectDB();
const app = express();

app.set('trust proxy', 1); 

// ─── Security ─────────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
}));
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200,
  message: { success: false, message: 'Too many requests. Please try again later.' }
}));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 15,
  message: { success: false, message: 'Too many auth attempts. Try later.' }
}));

// ─── Body / Logging ───────────────────────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));

// ─── Health ───────────────────────────────────────────────────────────────────
app.get('/health', (_, res) => res.json({ success: true, message: '⚡ Eventify API running', version: '1.0.0' }));

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/auth',         authRouter);
app.use('/api/events',       eventRouter);
app.use('/api/register',     registrationRouter);
app.use('/api/certificates', certRouter);
app.use('/api/notifications',notifRouter);
app.use('/api/clubs',        clubRouter);
app.use('/api/feedback',     feedbackRouter);
app.use('/api/admin',        adminRouter);

// ─── 404 ──────────────────────────────────────────────────────────────────────
app.use('*', (req, res) => res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found.` }));

// ─── Errors ───────────────────────────────────────────────────────────────────
app.use(errorHandler);

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
const server = app.listen(PORT, () =>
  console.log(`🚀 Eventify on :${PORT} [${process.env.NODE_ENV || 'development'}]`)
);
process.on('unhandledRejection', err => { console.error(err); server.close(() => process.exit(1)); });
module.exports = app;
