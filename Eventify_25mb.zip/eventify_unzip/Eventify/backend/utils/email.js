const nodemailer = require('nodemailer');

// ─── Transporter ──────────────────────────────────────────────────────────────
const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });
};

const FROM = process.env.EMAIL_FROM || 'Eventify <noreply@eventify.edu>';

// ─── Base Mailer ──────────────────────────────────────────────────────────────
const sendEmail = async ({ to, subject, html, text }) => {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
    console.log(`[Email skipped - not configured] To: ${to} | Subject: ${subject}`);
    return;
  }
  try {
    const transporter = createTransporter();
    await transporter.sendMail({ from: FROM, to, subject, html, text });
    console.log(`✅ Email sent to ${to}`);
  } catch (error) {
    console.error(`❌ Email failed to ${to}:`, error.message);
    // Don't throw — email failures should not break API responses
  }
};

// ─── HTML Template ────────────────────────────────────────────────────────────
const baseTemplate = (content) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Eventify</title>
</head>
<body style="margin:0;padding:0;background:#0a0f1e;font-family:'DM Sans',system-ui,sans-serif;">
  <div style="max-width:600px;margin:0 auto;padding:40px 20px;">
    <div style="text-align:center;margin-bottom:32px;">
      <div style="display:inline-flex;align-items:center;gap:8px;">
        <div style="width:36px;height:36px;background:#2563eb;border-radius:10px;display:flex;align-items:center;justify-content:center;">
          <span style="color:white;font-size:18px;font-weight:bold;">⚡</span>
        </div>
        <span style="color:white;font-size:22px;font-weight:700;">Eventify</span>
      </div>
    </div>
    <div style="background:#0d1528;border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:32px;">
      ${content}
    </div>
    <p style="text-align:center;color:#374151;font-size:12px;margin-top:24px;">
      © 2025 Eventify · University Event Management System<br>
      <a href="${process.env.CLIENT_URL}" style="color:#4b5563;">Visit Platform</a>
    </p>
  </div>
</body>
</html>
`;

// ─── Email Templates ──────────────────────────────────────────────────────────

/**
 * Welcome email after registration
 */
exports.sendWelcomeEmail = async ({ name, email, role }) => {
  const html = baseTemplate(`
    <h1 style="color:white;font-size:24px;margin:0 0 8px;">Welcome to Eventify, ${name}! 🎉</h1>
    <p style="color:#94a3b8;font-size:15px;line-height:1.6;margin:0 0 24px;">
      Your <strong style="color:#60a5fa;">${role}</strong> account has been created.
      Discover amazing campus events, join clubs, and earn certificates for your participation.
    </p>
    <a href="${process.env.CLIENT_URL}/events"
      style="display:inline-block;background:#2563eb;color:white;text-decoration:none;padding:12px 28px;border-radius:10px;font-weight:600;font-size:14px;">
      Explore Events →
    </a>
  `);
  await sendEmail({ to: email, subject: 'Welcome to Eventify! 🎉', html });
};

/**
 * Registration confirmation with ticket ID
 */
exports.sendRegistrationConfirmation = async ({ name, email, eventTitle, eventDate, ticketId, venue }) => {
  const html = baseTemplate(`
    <h1 style="color:white;font-size:22px;margin:0 0 8px;">Registration Confirmed! ✅</h1>
    <p style="color:#94a3b8;font-size:15px;margin:0 0 24px;">
      You're registered for <strong style="color:white;">${eventTitle}</strong>
    </p>
    <div style="background:#111b35;border:1px solid rgba(255,255,255,0.06);border-radius:12px;padding:20px;margin-bottom:24px;">
      <table style="width:100%;border-collapse:collapse;">
        ${[
          ['📅 Date', eventDate],
          ['📍 Venue', venue],
          ['🎫 Ticket ID', ticketId],
        ].map(([k, v]) => `
          <tr>
            <td style="color:#64748b;font-size:13px;padding:6px 0;width:120px;">${k}</td>
            <td style="color:#e2e8f0;font-size:13px;padding:6px 0;font-weight:500;">${v}</td>
          </tr>
        `).join('')}
      </table>
    </div>
    <p style="color:#64748b;font-size:13px;">Keep your Ticket ID safe. Present it at the venue for check-in.</p>
    <a href="${process.env.CLIENT_URL}/dashboard/student"
      style="display:inline-block;background:#2563eb;color:white;text-decoration:none;padding:12px 28px;border-radius:10px;font-weight:600;font-size:14px;margin-top:16px;">
      View My Events →
    </a>
  `);
  await sendEmail({ to: email, subject: `Registration Confirmed: ${eventTitle}`, html });
};

/**
 * Event approval notification to organizer
 */
exports.sendEventApprovalEmail = async ({ name, email, eventTitle, eventId }) => {
  const html = baseTemplate(`
    <h1 style="color:#10b981;font-size:22px;margin:0 0 8px;">Event Approved! 🎉</h1>
    <p style="color:#94a3b8;font-size:15px;margin:0 0 24px;">
      Great news, ${name}! Your event <strong style="color:white;">${eventTitle}</strong> 
      has been approved and is now live on Eventify.
    </p>
    <a href="${process.env.CLIENT_URL}/events/${eventId}"
      style="display:inline-block;background:#2563eb;color:white;text-decoration:none;padding:12px 28px;border-radius:10px;font-weight:600;font-size:14px;">
      View Event →
    </a>
  `);
  await sendEmail({ to: email, subject: `Your event "${eventTitle}" is now live!`, html });
};

/**
 * Certificate issuance notification
 */
exports.sendCertificateEmail = async ({ name, email, eventTitle, certificateId }) => {
  const html = baseTemplate(`
    <h1 style="color:white;font-size:22px;margin:0 0 8px;">Your Certificate is Ready! 🏆</h1>
    <p style="color:#94a3b8;font-size:15px;margin:0 0 8px;">
      Congratulations, ${name}! Your certificate for
    </p>
    <p style="color:#60a5fa;font-size:18px;font-weight:600;margin:0 0 24px;">${eventTitle}</p>
    <p style="color:#64748b;font-size:13px;margin:0 0 24px;">Certificate ID: <code style="background:#111b35;padding:4px 8px;border-radius:6px;color:#94a3b8;">${certificateId}</code></p>
    <a href="${process.env.CLIENT_URL}/certificates"
      style="display:inline-block;background:#7c3aed;color:white;text-decoration:none;padding:12px 28px;border-radius:10px;font-weight:600;font-size:14px;">
      Download Certificate →
    </a>
  `);
  await sendEmail({ to: email, subject: `Certificate Ready: ${eventTitle}`, html });
};

/**
 * Event cancellation notice to participants
 */
exports.sendCancellationEmail = async ({ name, email, eventTitle, reason }) => {
  const html = baseTemplate(`
    <h1 style="color:#f87171;font-size:22px;margin:0 0 8px;">Event Cancelled</h1>
    <p style="color:#94a3b8;font-size:15px;margin:0 0 24px;">
      Hi ${name}, we regret to inform you that <strong style="color:white;">${eventTitle}</strong> 
      has been cancelled${reason ? ': ' + reason : '.'}.
    </p>
    <p style="color:#64748b;font-size:13px;">Your registration has been removed automatically. We hope to see you at future events!</p>
    <a href="${process.env.CLIENT_URL}/events"
      style="display:inline-block;background:#2563eb;color:white;text-decoration:none;padding:12px 28px;border-radius:10px;font-weight:600;font-size:14px;margin-top:16px;">
      Explore Other Events →
    </a>
  `);
  await sendEmail({ to: email, subject: `Event Cancelled: ${eventTitle}`, html });
};

module.exports.sendEmail = sendEmail;
