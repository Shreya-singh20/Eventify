/**
 * Eventify - Database Seeder
 * Run: node backend/utils/seeder.js
 * Clear: node backend/utils/seeder.js --clear
 */

require('dotenv').config({ path: require('path').join(__dirname, '../.env') });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Event = require('../models/Event');
const { Club } = require('../models/index');

const USERS = [
  { name: 'Admin User', email: 'admin@eventify.edu', password: 'Admin@1234', role: 'admin', department: 'Computer Science' },
  { name: 'Alex Organizer', email: 'organizer@eventify.edu', password: 'Organizer@1234', role: 'organizer', department: 'Computer Science' },
  { name: 'Sam Student', email: 'student@eventify.edu', password: 'Student@1234', role: 'student', department: 'Electronics', year: 2, enrollmentNumber: 'CS2023001' },
  { name: 'Dr. Faculty', email: 'faculty@eventify.edu', password: 'Faculty@1234', role: 'faculty', department: 'Mathematics' },
];

const EVENTS_DATA = (organizerId) => [
  {
    title: 'National Hackathon 2025',
    description: 'A 48-hour hackathon where teams of 3-4 build innovative solutions for real-world problems. Cash prizes, internship offers, and networking opportunities await. Categories include EdTech, HealthTech, FinTech, and Open Innovation.',
    shortDescription: 'Build innovative solutions in 48 hours. ₹1L in prizes.',
    category: 'hackathon',
    date: { start: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), end: new Date(Date.now() + 9 * 24 * 60 * 60 * 1000) },
    registrationDeadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    venue: { name: 'Main Auditorium', address: 'University Campus, Block A', isOnline: false },
    organizer: organizerId,
    seats: { total: 200, available: 143 },
    fee: { isFree: true, amount: 0, currency: 'INR' },
    status: 'approved',
    isFeatured: true,
    tags: ['hackathon', 'coding', 'prizes', 'networking'],
    image: { url: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=1200', publicId: '' },
    speakers: [{ name: 'Priya Gupta', designation: 'CTO', organization: 'TechStartup Inc.', bio: 'Serial entrepreneur and tech leader.' }],
    analytics: { views: 1240, registrations: 57, attendance: 0 },
  },
  {
    title: 'Web Development Bootcamp',
    description: 'An intensive 3-day workshop covering modern web development from fundamentals to deployment. Learn React, Node.js, MongoDB, and build a full-stack project from scratch. Perfect for beginners and intermediate developers.',
    shortDescription: '3-day full-stack development workshop with project.',
    category: 'workshop',
    date: { start: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000) },
    venue: { name: 'CS Lab 101', address: 'Department of Computer Science', isOnline: false },
    organizer: organizerId,
    seats: { total: 60, available: 12 },
    fee: { isFree: false, amount: 499, currency: 'INR' },
    status: 'approved',
    isFeatured: true,
    tags: ['web', 'react', 'nodejs', 'mongodb', 'bootcamp'],
    image: { url: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200', publicId: '' },
    analytics: { views: 890, registrations: 48, attendance: 0 },
  },
  {
    title: 'Annual Cultural Night 2025',
    description: 'Experience the rich tapestry of cultures on campus! Annual Cultural Night features performances from 20+ clubs including classical dance, fusion music, street performances, comedy acts, and a grand fashion show. Food stalls from 15 cuisines.',
    shortDescription: 'Grand cultural extravaganza with 20+ performances.',
    category: 'cultural',
    date: { start: new Date(Date.now() + 21 * 24 * 60 * 60 * 1000) },
    venue: { name: 'University Amphitheater', address: 'Central Campus', isOnline: false },
    organizer: organizerId,
    seats: { total: 1000, available: 654 },
    fee: { isFree: false, amount: 150, currency: 'INR' },
    status: 'approved',
    isFeatured: true,
    tags: ['cultural', 'dance', 'music', 'entertainment'],
    image: { url: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=1200', publicId: '' },
    analytics: { views: 2100, registrations: 346, attendance: 0 },
  },
  {
    title: 'AI/ML Summit 2025',
    description: 'Join industry leaders and researchers for a day-long summit on Artificial Intelligence and Machine Learning. Sessions on LLMs, Computer Vision, MLOps, and responsible AI. Panel discussions, live demos, and networking lunch included.',
    shortDescription: 'Industry leaders discuss the future of AI and ML.',
    category: 'seminar',
    date: { start: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) },
    registrationDeadline: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000),
    venue: { name: 'Conference Hall', address: 'Block B, Floor 3', isOnline: false },
    organizer: organizerId,
    seats: { total: 300, available: 187 },
    fee: { isFree: true, amount: 0, currency: 'INR' },
    status: 'approved',
    tags: ['AI', 'ML', 'technology', 'summit'],
    image: { url: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=1200', publicId: '' },
    speakers: [
      { name: 'Dr. Rajesh Kumar', designation: 'AI Research Lead', organization: 'Google DeepMind India' },
      { name: 'Ananya Sinha', designation: 'ML Engineer', organization: 'OpenAI' },
    ],
    analytics: { views: 1580, registrations: 113, attendance: 0 },
  },
  {
    title: 'Inter-College Sports Meet',
    description: 'The biggest sporting event of the year brings together 30+ colleges for 15 different sports. Compete in cricket, football, basketball, badminton, chess, and more. All participants receive jerseys and participation certificates.',
    shortDescription: '30+ colleges, 15 sports, 5 days of intense competition.',
    category: 'sports',
    date: { start: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), end: new Date(Date.now() + 50 * 24 * 60 * 60 * 1000) },
    venue: { name: 'University Sports Complex', address: 'Sports Block, South Campus', isOnline: false },
    organizer: organizerId,
    seats: { total: 500, available: 289 },
    fee: { isFree: false, amount: 250, currency: 'INR' },
    status: 'approved',
    tags: ['sports', 'cricket', 'football', 'competition'],
    image: { url: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=1200', publicId: '' },
    analytics: { views: 920, registrations: 211, attendance: 0 },
  },
  {
    title: 'Research Paper Presentation',
    description: 'Annual inter-departmental research paper presentation event. Students present their research across domains: Computer Science, Engineering, Sciences, and Humanities. Best papers win publication opportunities in university journal.',
    shortDescription: 'Present your research to faculty and industry experts.',
    category: 'academic',
    date: { start: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000) },
    venue: { name: 'Seminar Hall', address: 'Academic Block, Room 305', isOnline: false },
    organizer: organizerId,
    seats: { total: 150, available: 98 },
    fee: { isFree: true, amount: 0, currency: 'INR' },
    status: 'approved',
    tags: ['research', 'academic', 'presentation', 'publication'],
    image: { url: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=1200', publicId: '' },
    analytics: { views: 430, registrations: 52, attendance: 0 },
  },
];

const CLUBS_DATA = (coordinatorId) => [
  {
    name: 'TechNova',
    slug: 'technova',
    description: 'The premier technical club on campus. We organize hackathons, coding contests, and tech talks. Open to all students passionate about technology.',
    category: 'technical',
    coordinator: coordinatorId,
  },
  {
    name: 'CulturEdge',
    slug: 'culturedge',
    description: 'Celebrating arts and culture through dance, music, drama, and fine arts. Annual fests and regular workshops.',
    category: 'cultural',
    coordinator: coordinatorId,
  },
];

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    if (process.argv[2] === '--clear') {
      await Promise.all([User.deleteMany(), Event.deleteMany(), Club.deleteMany()]);
      console.log('🗑️  Database cleared!');
      process.exit(0);
    }

    // Check existing
    const existingAdmin = await User.findOne({ email: 'admin@eventify.edu' });
    if (existingAdmin) {
      console.log('⚠️  Seed data already exists. Run with --clear first to reseed.');
      process.exit(0);
    }

    // Create users (passwords hashed by pre-save hook)
    const users = await User.create(USERS);
    console.log(`✅ Created ${users.length} users`);

    const admin = users.find(u => u.role === 'admin');
    const organizer = users.find(u => u.role === 'organizer');

    // Add welcome notifications
    for (const user of users) {
      user.notifications.push({
        message: `Welcome to Eventify, ${user.name}! Start exploring events.`,
        type: 'success',
      });
      await user.save();
    }

    // Create events
    const events = await Event.create(EVENTS_DATA(organizer._id));
    console.log(`✅ Created ${events.length} events`);

    // Register a student for the first event
    const student = users.find(u => u.role === 'student');
    const firstEvent = events[0];
    firstEvent.participants.push({ user: student._id, ticketId: 'EVT-DEMO0001', paymentStatus: 'free' });
    firstEvent.seats.available -= 1;
    await firstEvent.save();
    await User.findByIdAndUpdate(student._id, { $push: { registeredEvents: firstEvent._id } });

    // Create clubs
    const clubs = await Club.create(CLUBS_DATA(organizer._id));
    console.log(`✅ Created ${clubs.length} clubs`);

    console.log('\n🎉 Seeding complete!\n');
    console.log('Demo Accounts:');
    console.log('─────────────────────────────────────────');
    USERS.forEach(u => console.log(`  ${u.role.padEnd(10)} ${u.email.padEnd(30)} ${u.password}`));
    console.log('─────────────────────────────────────────\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  }
};

seed();
