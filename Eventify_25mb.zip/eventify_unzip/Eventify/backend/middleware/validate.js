const { body, param, query, validationResult } = require('express-validator');

// ─── Validation Runner ────────────────────────────────────────────────────────
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: errors.array()[0].msg,
      errors: errors.array().map(e => ({ field: e.path, message: e.msg })),
    });
  }
  next();
};

// ─── Auth Validators ──────────────────────────────────────────────────────────
exports.validateRegister = [
  body('name')
    .trim().notEmpty().withMessage('Name is required.')
    .isLength({ min: 2, max: 100 }).withMessage('Name must be 2–100 characters.'),
  body('email')
    .trim().notEmpty().withMessage('Email is required.')
    .isEmail().withMessage('Please provide a valid email address.')
    .normalizeEmail(),
  body('password')
    .notEmpty().withMessage('Password is required.')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters.'),
  body('role')
    .optional()
    .isIn(['student', 'organizer', 'faculty', 'admin'])
    .withMessage('Invalid role.'),
  body('year')
    .optional()
    .isInt({ min: 1, max: 5 }).withMessage('Year must be between 1 and 5.'),
  validate,
];

exports.validateLogin = [
  body('email').trim().notEmpty().withMessage('Email is required.').isEmail().withMessage('Invalid email.'),
  body('password').notEmpty().withMessage('Password is required.'),
  validate,
];

// ─── Event Validators ─────────────────────────────────────────────────────────
exports.validateCreateEvent = [
  body('title')
    .trim().notEmpty().withMessage('Event title is required.')
    .isLength({ max: 150 }).withMessage('Title must be under 150 characters.'),
  body('description')
    .trim().notEmpty().withMessage('Event description is required.')
    .isLength({ max: 5000 }).withMessage('Description must be under 5000 characters.'),
  body('category')
    .notEmpty().withMessage('Category is required.')
    .isIn(['technical', 'cultural', 'sports', 'academic', 'workshop', 'seminar', 'hackathon', 'other'])
    .withMessage('Invalid category.'),
  validate,
];

// ─── Registration Validators ──────────────────────────────────────────────────
exports.validateEventId = [
  param('eventId')
    .isMongoId().withMessage('Invalid event ID.'),
  validate,
];

// ─── Feedback Validators ──────────────────────────────────────────────────────
exports.validateFeedback = [
  body('rating')
    .notEmpty().withMessage('Rating is required.')
    .isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5.'),
  body('review')
    .optional()
    .isLength({ max: 1000 }).withMessage('Review must be under 1000 characters.'),
  body('aspects.content')
    .optional().isInt({ min: 1, max: 5 }).withMessage('Content score must be 1–5.'),
  body('aspects.organization')
    .optional().isInt({ min: 1, max: 5 }).withMessage('Organisation score must be 1–5.'),
  body('aspects.venue')
    .optional().isInt({ min: 1, max: 5 }).withMessage('Venue score must be 1–5.'),
  body('aspects.speaker')
    .optional().isInt({ min: 1, max: 5 }).withMessage('Speaker score must be 1–5.'),
  validate,
];

// ─── Password Validators ──────────────────────────────────────────────────────
exports.validateChangePassword = [
  body('currentPassword').notEmpty().withMessage('Current password is required.'),
  body('newPassword')
    .notEmpty().withMessage('New password is required.')
    .isLength({ min: 8 }).withMessage('New password must be at least 8 characters.'),
  validate,
];

// ─── Pagination Validators ────────────────────────────────────────────────────
exports.validatePagination = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer.').toInt(),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be 1–100.').toInt(),
  validate,
];
