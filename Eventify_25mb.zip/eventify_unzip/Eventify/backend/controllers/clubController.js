const { Club, Feedback } = require('../models/index');
const Event = require('../models/Event');
const User  = require('../models/User');

// ═══════════════════════════════════════════════════════════
//  CLUBS
// ═══════════════════════════════════════════════════════════

// @GET /api/clubs
exports.getClubs = async (req, res, next) => {
  try {
    const { category, search, page = 1, limit = 20 } = req.query;
    const query = { isActive: true };
    if (category) query.category = category;
    if (search)   query.$text = { $search: search };

    const clubs = await Club.find(query)
      .populate('coordinator', 'name avatar department')
      .sort('-createdAt')
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await Club.countDocuments(query);
    res.json({ success: true, clubs, total });
  } catch (err) { next(err); }
};

// @GET /api/clubs/:slug
exports.getClub = async (req, res, next) => {
  try {
    const club = await Club.findOne({ slug: req.params.slug })
      .populate('coordinator', 'name avatar email department')
      .populate({ path: 'members.user', select: 'name avatar department year' })
      .populate({ path: 'events', select: 'title date image category status', options: { limit: 10 } });

    if (!club) return res.status(404).json({ success: false, message: 'Club not found.' });
    res.json({ success: true, club });
  } catch (err) { next(err); }
};

// @POST /api/clubs
exports.createClub = async (req, res, next) => {
  try {
    const club = await Club.create({ ...req.body, coordinator: req.user.id });
    res.status(201).json({ success: true, club });
  } catch (err) { next(err); }
};

// @PUT /api/clubs/:id
exports.updateClub = async (req, res, next) => {
  try {
    const club = await Club.findById(req.params.id);
    if (!club) return res.status(404).json({ success: false, message: 'Club not found.' });
    if (club.coordinator.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }
    const updated = await Club.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.json({ success: true, club: updated });
  } catch (err) { next(err); }
};

// @POST /api/clubs/:id/join
exports.joinClub = async (req, res, next) => {
  try {
    const club = await Club.findById(req.params.id);
    if (!club) return res.status(404).json({ success: false, message: 'Club not found.' });

    const alreadyMember = club.members.some(m => m.user.toString() === req.user.id);
    if (alreadyMember) return res.status(400).json({ success: false, message: 'Already a member.' });

    club.members.push({ user: req.user.id, role: 'member' });
    await club.save();
    res.json({ success: true, message: 'Joined club successfully.' });
  } catch (err) { next(err); }
};

// @DELETE /api/clubs/:id/leave
exports.leaveClub = async (req, res, next) => {
  try {
    const club = await Club.findById(req.params.id);
    if (!club) return res.status(404).json({ success: false, message: 'Club not found.' });

    club.members = club.members.filter(m => m.user.toString() !== req.user.id);
    await club.save();
    res.json({ success: true, message: 'Left club.' });
  } catch (err) { next(err); }
};

// ═══════════════════════════════════════════════════════════
//  FEEDBACK
// ═══════════════════════════════════════════════════════════

// @POST /api/feedback/:eventId
exports.submitFeedback = async (req, res, next) => {
  try {
    const { rating, review, isAnonymous, aspects } = req.body;
    const eventId = req.params.eventId;

    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    // Must have been a participant
    const participant = event.participants.find(p => p.user.toString() === req.user.id);
    if (!participant) {
      return res.status(400).json({ success: false, message: 'You must register and attend this event to leave feedback.' });
    }

    const existing = await Feedback.findOne({ user: req.user.id, event: eventId });
    if (existing) return res.status(400).json({ success: false, message: 'You have already submitted feedback for this event.' });

    const feedback = await Feedback.create({
      user: req.user.id,
      event: eventId,
      rating,
      review,
      isAnonymous: isAnonymous || false,
      aspects: aspects || {},
    });

    // Push to event's feedback array
    event.feedback.push(feedback._id);
    await event.save();

    res.status(201).json({ success: true, feedback });
  } catch (err) { next(err); }
};

// @GET /api/feedback/:eventId
exports.getEventFeedback = async (req, res, next) => {
  try {
    const feedback = await Feedback.find({ event: req.params.eventId })
      .populate('user', 'name avatar department')
      .sort('-createdAt');

    const sanitized = feedback.map(f => ({
      ...f.toObject(),
      user: f.isAnonymous ? null : f.user,
    }));

    const avgRating = feedback.length
      ? (feedback.reduce((a, f) => a + f.rating, 0) / feedback.length).toFixed(1)
      : null;

    res.json({ success: true, feedback: sanitized, avgRating, total: feedback.length });
  } catch (err) { next(err); }
};

// ═══════════════════════════════════════════════════════════
//  ADMIN — USERS
// ═══════════════════════════════════════════════════════════

// @GET /api/admin/users
exports.getUsers = async (req, res, next) => {
  try {
    const { search, role, page = 1, limit = 15 } = req.query;
    const query = {};
    if (role)   query.role = role;
    if (search) {
      query.$or = [
        { name:  { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const total = await User.countDocuments(query);
    const users = await User.find(query)
      .select('-password -notifications -resetPasswordToken -resetPasswordExpire')
      .sort('-createdAt')
      .skip((page - 1) * parseInt(limit))
      .limit(parseInt(limit));

    res.json({ success: true, users, total });
  } catch (err) { next(err); }
};

// @PUT /api/admin/users/:id/role
exports.updateUserRole = async (req, res, next) => {
  try {
    const { role } = req.body;
    const validRoles = ['student', 'organizer', 'faculty', 'admin'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role.' });
    }
    const user = await User.findByIdAndUpdate(
      req.params.id, { role }, { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    res.json({ success: true, user });
  } catch (err) { next(err); }
};

// @PUT /api/admin/users/:id/toggle
exports.toggleUserActive = async (req, res, next) => {
  try {
    const { isActive } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id, { isActive }, { new: true }
    ).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    res.json({ success: true, user });
  } catch (err) { next(err); }
};

// @DELETE /api/admin/users/:id
exports.deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select('role');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

    if (user._id.toString() === req.user.id) {
      return res.status(400).json({ success: false, message: 'You cannot delete your own account.' });
    }

    if (user.role === 'admin') {
      const adminCount = await User.countDocuments({ role: 'admin', isActive: true });
      if (adminCount <= 1) {
        return res.status(400).json({ success: false, message: 'Cannot delete the last active admin.' });
      }
    }

    const eventIds = await Event.find({ organizer: user._id }).distinct('_id');

    await Promise.all([
      Event.deleteMany({ organizer: user._id }),
      Club.updateMany(
        { 'members.user': user._id },
        { $pull: { members: { user: user._id } } }
      ),
      Club.updateMany(
        { coordinator: user._id },
        { $set: { isActive: false } }
      ),
      Feedback.deleteMany({ user: user._id }),
      User.updateMany(
        {},
        {
          $pull: {
            registeredEvents: { $in: eventIds },
            notifications: { eventId: { $in: eventIds } },
          },
        }
      ),
    ]);

    await User.findByIdAndDelete(user._id);
    res.json({ success: true, message: 'User deleted successfully.' });
  } catch (err) { next(err); }
};
