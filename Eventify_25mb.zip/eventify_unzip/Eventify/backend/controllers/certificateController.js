const { Certificate } = require('../models/index');
const Event = require('../models/Event');
const User = require('../models/User');
const { v4: uuidv4 } = require('uuid');
const PDFDocument = require('pdfkit');

// ─── @GET /api/certificates ───────────────────────────────────────────────────
exports.getMyCertificates = async (req, res, next) => {
  try {
    const certificates = await Certificate.find({ user: req.user.id, isValid: true })
      .populate('event', 'title date venue image category organizer')
      .sort('-issuedAt');

    res.status(200).json({ success: true, certificates });
  } catch (error) {
    next(error);
  }
};

// ─── @POST /api/certificate/generate ─────────────────────────────────────────
exports.generateCertificate = async (req, res, next) => {
  try {
    const { eventId, userId, type = 'participation' } = req.body;

    // Verify organizer/admin
    if (req.user.role !== 'organizer' && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }

    const event = await Event.findById(eventId).populate('organizer', 'name');
    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    const targetUser = await User.findById(userId);
    if (!targetUser) return res.status(404).json({ success: false, message: 'User not found.' });

    // Check if participant attended
    const participant = event.participants.find(p => p.user.toString() === userId);
    if (!participant || !participant.attended) {
      return res.status(400).json({ success: false, message: 'User did not attend this event.' });
    }

    // Check if certificate already exists
    const existing = await Certificate.findOne({ user: userId, event: eventId });
    if (existing) {
      return res.status(400).json({ success: false, message: 'Certificate already issued.' });
    }

    const certId = `CERT-${uuidv4().substring(0, 10).toUpperCase()}`;
    const certificate = await Certificate.create({
      certificateId: certId,
      user: userId,
      event: eventId,
      type,
    });

    // Notify user
    await User.findByIdAndUpdate(userId, {
      $push: {
        notifications: {
          message: `Your certificate for "${event.title}" is ready to download!`,
          type: 'success',
          eventId: event._id,
        },
      },
    });

    res.status(201).json({ success: true, certificate });
  } catch (error) {
    next(error);
  }
};

// ─── @GET /api/certificate/:id/download ──────────────────────────────────────
exports.downloadCertificate = async (req, res, next) => {
  try {
    const certificate = await Certificate.findById(req.params.id)
      .populate('user', 'name enrollmentNumber')
      .populate('event', 'title date venue organizer');

    if (!certificate) {
      return res.status(404).json({ success: false, message: 'Certificate not found.' });
    }

    if (certificate.user._id.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }

    // Generate PDF
    const doc = new PDFDocument({ size: 'A4', layout: 'landscape', margin: 50 });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename=certificate-${certificate.certificateId}.pdf`);
    doc.pipe(res);

    // Certificate design
    const { width, height } = doc.page;

    // Background
    doc.rect(0, 0, width, height).fill('#0f172a');
    doc.rect(20, 20, width - 40, height - 40).fill('#1e293b');

    // Border decoration
    doc.rect(30, 30, width - 60, height - 60).stroke('#f59e0b').lineWidth(2);
    doc.rect(35, 35, width - 70, height - 70).stroke('#f59e0b').lineWidth(0.5);

    // Title
    doc.font('Helvetica-Bold')
       .fontSize(42)
       .fillColor('#f59e0b')
       .text('CERTIFICATE', 0, 80, { align: 'center' });

    doc.font('Helvetica')
       .fontSize(16)
       .fillColor('#94a3b8')
       .text('OF PARTICIPATION', 0, 130, { align: 'center' });

    // Divider
    doc.moveTo(width / 2 - 100, 165).lineTo(width / 2 + 100, 165).stroke('#f59e0b').lineWidth(1);

    // Body text
    doc.font('Helvetica')
       .fontSize(14)
       .fillColor('#cbd5e1')
       .text('This is to certify that', 0, 185, { align: 'center' });

    doc.font('Helvetica-Bold')
       .fontSize(28)
       .fillColor('#ffffff')
       .text(certificate.user.name, 0, 210, { align: 'center' });

    if (certificate.user.enrollmentNumber) {
      doc.font('Helvetica')
         .fontSize(12)
         .fillColor('#94a3b8')
         .text(`Enrollment: ${certificate.user.enrollmentNumber}`, 0, 250, { align: 'center' });
    }

    doc.font('Helvetica')
       .fontSize(14)
       .fillColor('#cbd5e1')
       .text('has successfully participated in', 0, 280, { align: 'center' });

    doc.font('Helvetica-Bold')
       .fontSize(22)
       .fillColor('#38bdf8')
       .text(certificate.event.title, 0, 305, { align: 'center' });

    const eventDate = new Date(certificate.event.date?.start).toLocaleDateString('en-IN', {
      day: 'numeric', month: 'long', year: 'numeric',
    });

    doc.font('Helvetica')
       .fontSize(12)
       .fillColor('#94a3b8')
       .text(`held on ${eventDate}`, 0, 340, { align: 'center' });

    // Certificate ID
    doc.font('Helvetica')
       .fontSize(10)
       .fillColor('#475569')
       .text(`Certificate ID: ${certificate.certificateId}`, 0, height - 80, { align: 'center' });

    // Eventify branding
    doc.font('Helvetica-Bold')
       .fontSize(18)
       .fillColor('#f59e0b')
       .text('Eventify', 0, height - 60, { align: 'center' });

    doc.font('Helvetica')
       .fontSize(9)
       .fillColor('#475569')
       .text('University Event Management System', 0, height - 42, { align: 'center' });

    doc.end();
  } catch (error) {
    next(error);
  }
};

// ─── @GET /api/notifications ──────────────────────────────────────────────────
exports.getNotifications = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).select('notifications');
    const notifications = user.notifications.sort((a, b) => b.createdAt - a.createdAt);

    res.status(200).json({ success: true, notifications });
  } catch (error) {
    next(error);
  }
};

// ─── @PUT /api/notifications/read ────────────────────────────────────────────
exports.markNotificationsRead = async (req, res, next) => {
  try {
    await User.updateOne(
      { _id: req.user.id },
      { $set: { 'notifications.$[].isRead': true } }
    );
    res.status(200).json({ success: true, message: 'All notifications marked as read.' });
  } catch (error) {
    next(error);
  }
};

// ─── @GET /api/admin/stats ────────────────────────────────────────────────────
exports.getAdminStats = async (req, res, next) => {
  try {
    const [totalUsers, totalEvents, pendingEvents, certificates] = await Promise.all([
      User.countDocuments(),
      Event.countDocuments(),
      Event.countDocuments({ status: 'pending' }),
      Certificate.countDocuments(),
    ]);

    const usersByRole = await User.aggregate([
      { $group: { _id: '$role', count: { $sum: 1 } } },
    ]);

    const eventsByCategory = await Event.aggregate([
      { $match: { status: 'approved' } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
    ]);

    const recentEvents = await Event.find()
      .sort('-createdAt')
      .limit(5)
      .populate('organizer', 'name');

    res.status(200).json({
      success: true,
      stats: {
        totalUsers,
        totalEvents,
        pendingEvents,
        certificates,
        usersByRole,
        eventsByCategory,
        recentEvents,
      },
    });
  } catch (error) {
    next(error);
  }
};
