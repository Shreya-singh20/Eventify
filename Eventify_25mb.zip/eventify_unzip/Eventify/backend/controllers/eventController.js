const Event = require('../models/Event');
const User = require('../models/User');

// ─── @GET /api/events ─────────────────────────────────────────────────────────
exports.getEvents = async (req, res, next) => {
  try {
    const {
      search, category, status = 'approved', isFeatured,
      page = 1, limit = 12, sort = '-date.start',
      dateFrom, dateTo, isFree,
    } = req.query;

    const query = {};

    // Role-based visibility
    if (!req.user || req.user.role === 'student') {
      query.status = 'approved';
      query.isPublic = true;
    } else if (req.user.role === 'organizer') {
      query.$or = [{ status: 'approved' }, { organizer: req.user.id }];
    } else if (req.user.role === 'admin') {
      if (status) query.status = status;
    }

    // Search
    if (search) {
      query.$text = { $search: search };
    }

    // Filters
    if (category) query.category = category;
    if (isFeatured === 'true') query.isFeatured = true;
    if (isFree === 'true') query['fee.isFree'] = true;

    // Date range
    if (dateFrom || dateTo) {
      query['date.start'] = {};
      if (dateFrom) query['date.start'].$gte = new Date(dateFrom);
      if (dateTo) query['date.start'].$lte = new Date(dateTo);
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Event.countDocuments(query);

    const events = await Event.find(query)
      .populate('organizer', 'name avatar department')
      .populate('club', 'name logo')
      .sort(sort)
      .skip(skip)
      .limit(parseInt(limit));

    res.status(200).json({
      success: true,
      count: events.length,
      total,
      totalPages: Math.ceil(total / parseInt(limit)),
      currentPage: parseInt(page),
      events,
    });
  } catch (error) {
    next(error);
  }
};

// ─── @GET /api/events/:id ─────────────────────────────────────────────────────
exports.getEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate('organizer', 'name avatar email department')
      .populate('club', 'name logo description')
      .populate('participants.user', 'name avatar enrollmentNumber department')
      .populate({ path: 'feedback', populate: { path: 'user', select: 'name avatar' } });

    if (!event) {
      return res.status(404).json({ success: false, message: 'Event not found.' });
    }

    // Increment views
    await Event.findByIdAndUpdate(req.params.id, { $inc: { 'analytics.views': 1 } });

    res.status(200).json({ success: true, event });
  } catch (error) {
    next(error);
  }
};

// ─── @POST /api/events/create ─────────────────────────────────────────────────
exports.createEvent = async (req, res, next) => {
  try {
    const eventData = {
      ...req.body,
      organizer: req.user.id,
      status: req.user.role === 'admin' ? 'approved' : 'pending',
    };

    if (req.file) {
      eventData.image = {
        url: req.file.path,
        publicId: req.file.filename,
      };
    }

    // Parse nested objects from form-data
    if (typeof req.body.venue === 'string') {
      try { eventData.venue = JSON.parse(req.body.venue); } catch {}
    }
    if (typeof req.body.date === 'string') {
      try { eventData.date = JSON.parse(req.body.date); } catch {}
    }
    if (typeof req.body.fee === 'string') {
      try { eventData.fee = JSON.parse(req.body.fee); } catch {}
    }
    if (typeof req.body.seats === 'string') {
      try { eventData.seats = JSON.parse(req.body.seats); } catch {}
    }
    if (typeof req.body.speakers === 'string') {
      try { eventData.speakers = JSON.parse(req.body.speakers); } catch {}
    }
    if (typeof req.body.tags === 'string') {
      try { eventData.tags = JSON.parse(req.body.tags); } catch {}
    }

    const event = await Event.create(eventData);

    // Notify admin for approval
    if (req.user.role !== 'admin') {
      const admins = await User.find({ role: 'admin' });
      const notifPromises = admins.map(admin => {
        admin.notifications.push({
          message: `New event "${event.title}" pending approval.`,
          type: 'info',
          eventId: event._id,
        });
        return admin.save();
      });
      await Promise.all(notifPromises);
    }

    await event.populate('organizer', 'name avatar');
    res.status(201).json({ success: true, event });
  } catch (error) {
    next(error);
  }
};

// ─── @PUT /api/events/:id ─────────────────────────────────────────────────────
exports.updateEvent = async (req, res, next) => {
  try {
    let event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    // Authorization
    if (event.organizer.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to update this event.' });
    }

    const updates = { ...req.body };
    if (req.file) {
      updates.image = { url: req.file.path, publicId: req.file.filename };
    }

    event = await Event.findByIdAndUpdate(req.params.id, updates, {
      new: true,
      runValidators: true,
    }).populate('organizer', 'name avatar');

    res.status(200).json({ success: true, event });
  } catch (error) {
    next(error);
  }
};

// ─── @DELETE /api/events/:id ──────────────────────────────────────────────────
exports.deleteEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    if (event.organizer.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this event.' });
    }

    // Notify registered participants
    if (event.participants.length > 0) {
      const participantIds = event.participants.map(p => p.user);
      await User.updateMany(
        { _id: { $in: participantIds } },
        {
          $push: {
            notifications: {
              message: `Event "${event.title}" has been cancelled.`,
              type: 'warning',
            },
          },
          $pull: { registeredEvents: event._id },
        }
      );
    }

    await event.deleteOne();
    res.status(200).json({ success: true, message: 'Event deleted successfully.' });
  } catch (error) {
    next(error);
  }
};

// ─── @PUT /api/events/:id/approve ────────────────────────────────────────────
exports.approveEvent = async (req, res, next) => {
  try {
    const event = await Event.findByIdAndUpdate(
      req.params.id,
      { status: 'approved' },
      { new: true }
    ).populate('organizer', 'name email');

    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    // Notify organizer
    await User.findByIdAndUpdate(event.organizer._id, {
      $push: {
        notifications: {
          message: `Your event "${event.title}" has been approved!`,
          type: 'success',
          eventId: event._id,
        },
      },
    });

    res.status(200).json({ success: true, event });
  } catch (error) {
    next(error);
  }
};

// ─── @GET /api/events/my-events (organizer's events) ─────────────────────────
exports.getMyEvents = async (req, res, next) => {
  try {
    const events = await Event.find({ organizer: req.user.id })
      .sort('-createdAt')
      .populate('club', 'name');

    res.status(200).json({ success: true, events });
  } catch (error) {
    next(error);
  }
};

// ─── @GET /api/events/:id/attendance ─────────────────────────────────────────
exports.getAttendance = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate('participants.user', 'name enrollmentNumber department year avatar email');

    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    if (event.organizer.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }

    res.status(200).json({ success: true, participants: event.participants });
  } catch (error) {
    next(error);
  }
};

// ─── @PUT /api/events/:id/attendance ─────────────────────────────────────────
exports.markAttendance = async (req, res, next) => {
  try {
    const { userId, attended } = req.body;
    const event = await Event.findById(req.params.id);

    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    if (event.organizer.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }

    const participant = event.participants.find(p => p.user.toString() === userId);
    if (!participant) {
      return res.status(404).json({ success: false, message: 'Participant not found.' });
    }

    participant.attended = attended;
    if (attended) event.analytics.attendance += 1;
    await event.save();

    res.status(200).json({ success: true, message: 'Attendance updated.' });
  } catch (error) {
    next(error);
  }
};
