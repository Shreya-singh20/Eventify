const Event = require('../models/Event');
const User = require('../models/User');
const { v4: uuidv4 } = require('uuid');

// ─── @POST /api/register/:eventId ────────────────────────────────────────────
exports.registerForEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    if (event.status !== 'approved') {
      return res.status(400).json({ success: false, message: 'Event is not open for registration.' });
    }

    if (event.registrationDeadline && new Date() > event.registrationDeadline) {
      return res.status(400).json({ success: false, message: 'Registration deadline has passed.' });
    }

    if (event.seats.available <= 0) {
      return res.status(400).json({ success: false, message: 'No seats available.' });
    }

    // Check if already registered
    const alreadyRegistered = event.participants.some(
      p => p.user.toString() === req.user.id
    );
    if (alreadyRegistered) {
      return res.status(400).json({ success: false, message: 'You are already registered for this event.' });
    }

    const ticketId = `EVT-${uuidv4().substring(0, 8).toUpperCase()}`;

    // Add participant
    event.participants.push({
      user: req.user.id,
      ticketId,
      paymentStatus: event.fee.isFree ? 'free' : 'pending',
    });
    event.seats.available -= 1;
    event.analytics.registrations += 1;
    await event.save();

    // Add to user's registered events
    await User.findByIdAndUpdate(req.user.id, {
      $addToSet: { registeredEvents: event._id },
      $push: {
        notifications: {
          message: `You have successfully registered for "${event.title}". Ticket ID: ${ticketId}`,
          type: 'success',
          eventId: event._id,
        },
      },
    });

    // Notify organizer
    await User.findByIdAndUpdate(event.organizer, {
      $push: {
        notifications: {
          message: `New registration for "${event.title}". ${event.seats.available} seats remaining.`,
          type: 'info',
          eventId: event._id,
        },
      },
    });

    res.status(200).json({
      success: true,
      message: 'Registration successful!',
      ticketId,
    });
  } catch (error) {
    next(error);
  }
};

// ─── @GET /api/my-events ──────────────────────────────────────────────────────
exports.getMyRegisteredEvents = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id)
      .populate({
        path: 'registeredEvents',
        select: 'title date venue image category status fee organizer',
        populate: { path: 'organizer', select: 'name' },
      });

    res.status(200).json({ success: true, events: user.registeredEvents });
  } catch (error) {
    next(error);
  }
};

// ─── @DELETE /api/cancel/:eventId ─────────────────────────────────────────────
exports.cancelRegistration = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ success: false, message: 'Event not found.' });

    // Can't cancel after event starts
    if (new Date() > event.date.start) {
      return res.status(400).json({ success: false, message: 'Cannot cancel after event has started.' });
    }

    const participantIndex = event.participants.findIndex(
      p => p.user.toString() === req.user.id
    );
    if (participantIndex === -1) {
      return res.status(400).json({ success: false, message: 'You are not registered for this event.' });
    }

    event.participants.splice(participantIndex, 1);
    event.seats.available += 1;
    await event.save();

    await User.findByIdAndUpdate(req.user.id, {
      $pull: { registeredEvents: event._id },
      $push: {
        notifications: {
          message: `Your registration for "${event.title}" has been cancelled.`,
          type: 'warning',
          eventId: event._id,
        },
      },
    });

    res.status(200).json({ success: true, message: 'Registration cancelled successfully.' });
  } catch (error) {
    next(error);
  }
};
