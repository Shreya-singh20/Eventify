const mongoose = require('mongoose');

// ─── Club Schema ─────────────────────────────────────────────────────────────
const clubSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  slug: { type: String, unique: true, lowercase: true },
  description: { type: String, required: true, maxlength: 2000 },
  logo: {
    url: { type: String, default: '' },
    publicId: { type: String, default: '' },
  },
  coverImage: {
    url: { type: String, default: '' },
    publicId: { type: String, default: '' },
  },
  category: {
    type: String,
    enum: ['technical', 'cultural', 'sports', 'academic', 'social', 'other'],
  },
  coordinator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  members: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    role: { type: String, enum: ['member', 'core', 'lead'], default: 'member' },
    joinedAt: { type: Date, default: Date.now },
  }],
  social: {
    instagram: String,
    linkedin: String,
    website: String,
    email: String,
  },
  isActive: { type: Boolean, default: true },
  events: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Event' }],
}, { timestamps: true });

clubSchema.pre('save', function (next) {
  if (!this.slug) {
    this.slug = this.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  }
  next();
});

// ─── Certificate Schema ───────────────────────────────────────────────────────
const certificateSchema = new mongoose.Schema({
  certificateId: {
    type: String,
    unique: true,
    required: true,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  event: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Event',
    required: true,
  },
  type: {
    type: String,
    enum: ['participation', 'winner', 'organizer', 'volunteer', 'speaker'],
    default: 'participation',
  },
  issuedAt: { type: Date, default: Date.now },
  isValid: { type: Boolean, default: true },
  downloadUrl: { type: String },
}, { timestamps: true });

// ─── Feedback Schema ──────────────────────────────────────────────────────────
const feedbackSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  event: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Event',
    required: true,
  },
  rating: {
    type: Number,
    required: true,
    min: 1,
    max: 5,
  },
  review: {
    type: String,
    maxlength: 1000,
  },
  aspects: {
    content: { type: Number, min: 1, max: 5 },
    organization: { type: Number, min: 1, max: 5 },
    venue: { type: Number, min: 1, max: 5 },
    speaker: { type: Number, min: 1, max: 5 },
  },
  isAnonymous: { type: Boolean, default: false },
}, { timestamps: true });

feedbackSchema.index({ user: 1, event: 1 }, { unique: true });

const Club = mongoose.model('Club', clubSchema);
const Certificate = mongoose.model('Certificate', certificateSchema);
const Feedback = mongoose.model('Feedback', feedbackSchema);

module.exports = { Club, Certificate, Feedback };
