const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Event title is required'],
    trim: true,
    maxlength: [150, 'Title cannot exceed 150 characters'],
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    maxlength: [5000, 'Description cannot exceed 5000 characters'],
  },
  shortDescription: {
    type: String,
    maxlength: [250, 'Short description cannot exceed 250 characters'],
  },
  date: {
    start: { type: Date, required: [true, 'Start date is required'] },
    end: { type: Date },
  },
  registrationDeadline: { type: Date },
  venue: {
    name: { type: String, required: true },
    address: { type: String },
    googleMapsLink: { type: String },
    isOnline: { type: Boolean, default: false },
    meetLink: { type: String },
  },
  organizer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  club: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Club',
  },
  image: {
    url: { type: String, default: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=1200' },
    publicId: { type: String, default: '' },
  },
  category: {
    type: String,
    enum: ['technical', 'cultural', 'sports', 'academic', 'workshop', 'seminar', 'hackathon', 'other'],
    required: true,
  },
  tags: [{ type: String, trim: true }],
  seats: {
    total: { type: Number, required: true, min: 1 },
    available: { type: Number },
  },
  participants: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    registeredAt: { type: Date, default: Date.now },
    attended: { type: Boolean, default: false },
    paymentStatus: { type: String, enum: ['pending', 'completed', 'failed', 'free'], default: 'free' },
    ticketId: { type: String },
  }],
  fee: {
    amount: { type: Number, default: 0 },
    currency: { type: String, default: 'INR' },
    isFree: { type: Boolean, default: true },
  },
  speakers: [{
    name: String,
    designation: String,
    organization: String,
    avatar: String,
    bio: String,
  }],
  status: {
    type: String,
    enum: ['draft', 'pending', 'approved', 'cancelled', 'completed'],
    default: 'draft',
  },
  isFeatured: { type: Boolean, default: false },
  isPublic: { type: Boolean, default: true },
  feedback: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Feedback' }],
  analytics: {
    views: { type: Number, default: 0 },
    registrations: { type: Number, default: 0 },
    attendance: { type: Number, default: 0 },
  },
  certificatesIssued: { type: Boolean, default: false },
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true },
});

// Virtual: seats available
eventSchema.pre('save', function (next) {
  if (this.isNew) {
    this.seats.available = this.seats.total;
  }
  next();
});

// Virtual: is event full
eventSchema.virtual('isFull').get(function () {
  const available = this.seats?.available;
  return typeof available === 'number' ? available <= 0 : false;
});

// Virtual: participant count
eventSchema.virtual('participantCount').get(function () {
  return Array.isArray(this.participants) ? this.participants.length : 0;
});

// Indexes
eventSchema.index({ title: 'text', description: 'text', tags: 'text' });
eventSchema.index({ 'date.start': 1 });
eventSchema.index({ category: 1 });
eventSchema.index({ status: 1 });
eventSchema.index({ organizer: 1 });

module.exports = mongoose.model('Event', eventSchema);
